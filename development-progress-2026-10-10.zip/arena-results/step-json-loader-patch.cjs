'use strict';
// Pending loader correctness patch. Pure source transformation: never writes
// files or mutates a running engine. Apply only after the current match batch.
function apply(source){
  source=source.replace(/\r\n/g,'\n');
  function once(anchor,replacement){if(source.split(anchor).length!==2)throw new Error('JSON loader patch anchor changed: '+anchor.slice(0,80));source=source.replace(anchor,replacement);}
  once("    const original=fs.readFileSync(file,'utf8');let source=original;",`    const bytes=fs.readFileSync(file),original=bytes.toString('utf8');let source=original;
    if(path.extname(file).toLowerCase()==='.json'){
      // Each loadEngine owns its complete local JSON snapshot. Native require
      // would silently share model data across normal and frozen versions.
      const mod={exports:JSON.parse(original.replace(/^\\uFEFF/,''))};cache.set(file,mod);
      adapted.push({file:path.relative(ROOT,file).replaceAll('\\\\','/'),sourceSha256:sha(bytes),adapter:'json-isolated-unmodified'});
      return mod.exports;
    }`);
  once("      if(frozenPlayer!==null&&resolved.startsWith(ROOT+path.sep)&&/\\.(?:js|cjs)$/.test(resolved))return compile(resolved);", "      if(resolved.startsWith(ROOT+path.sep)&&/\\.(?:js|cjs|json)$/i.test(resolved))return compile(resolved);");
  once("sourceSha256:sha(original),adapter:mode", "sourceSha256:sha(bytes),adapter:mode");
  once("  return {engine,metadata:{file:absolute,sourceSha256:sha(fs.readFileSync(absolute,'utf8')),frozenPlayer,modules:adapted}};", `  const compiledRoot=adapted.find(row=>row.file===path.relative(ROOT,absolute).replaceAll('\\\\','/'));
  assert.ok(compiledRoot,'Compiled engine metadata is missing');
  return {engine,metadata:{file:absolute,sourceSha256:compiledRoot.sourceSha256,frozenPlayer,modules:adapted}};`);
  return source;
}
module.exports={apply};
