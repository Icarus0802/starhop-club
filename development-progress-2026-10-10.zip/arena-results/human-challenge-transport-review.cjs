'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const E = require('../js/engine.js'), A = require('../js/ai.js');
const file = path.join(__dirname, 'human-challenge-2026-10-10.json');
const raw = fs.readFileSync(file), record = JSON.parse(raw), replay = E.replay(record);
const near = (p, i) => Math.min(...E.zones[(p + 3) % 6].map(g => E.distances[i][g]));
const gain = (board, from, rules) => Math.max(0, ...E.pieceMoves(board, from, rules).map(m => near(board[from], from) - near(board[from], m.to)));
const describe = m => ({from: E.coord(m.from), to: E.coord(m.to), path: m.path.map(E.coord)});
function bridges(board, move) {
  const result = [];
  for (let j = 1; j < move.path.length; j++) {
    const from = move.path[j - 1], to = move.path[j];
    if (E.distances[from][to] !== 2) continue;
    const a = E.cells[from], b = E.cells[to], mid = E.at((a.r + b.r) / 2, (a.c + b.c) / 2);
    result.push({from: E.coord(from), to: E.coord(to), bridge: E.coord(mid), color: board[mid] === 3 ? 'green' : board[mid] === 0 ? 'red' : 'other'});
  }
  return result;
}
const greenEffects = [], redSelfEffects = [], redTrack = new Map();
for (let i = 0; i < 121; i++) if (replay.states[0].board[i] === 0) redTrack.set(i, {initial: E.coord(i), moves: []});
for (let ply = 1; ply <= record.moves.length; ply++) {
  const before = replay.states[ply - 1], after = replay.states[ply], move = replay.moves[ply - 1];
  const color = before.board[move.from], changes = [];
  if (color === 0) { const t = redTrack.get(move.from); t.moves.push({ply, ...describe(move)}); redTrack.delete(move.from); redTrack.set(move.to, t); }
  for (let i = 0; i < 121; i++) if (before.board[i] === 0 && i !== move.from) {
    const ma = E.pieceMoves(before.board, i, before.rules), mb = E.pieceMoves(after.board, i, after.rules);
    const beforeGain = gain(before.board, i, before.rules), afterGain = gain(after.board, i, after.rules);
    if (afterGain >= beforeGain) continue;
    const lost = ma.filter(m => near(0, i) - near(0, m.to) >= 1 && !mb.some(n => n.to === m.to));
    changes.push({piece: E.coord(i), beforeGain, afterGain, beforeMoves: ma.length, afterMoves: mb.length,
      lostRoutes: lost.map(m => ({...describe(m), gain: near(0, i) - near(0, m.to), occupiedLanding: m.path.includes(move.to) ? E.coord(move.to) : null,
        vacatedBridge: bridges(before.board, m).some(b => b.bridge === E.coord(move.from)) ? E.coord(move.from) : null}))});
  }
  if (changes.length || ply === 66) (color === 3 ? greenEffects : redSelfEffects).push({ply, move: describe(move), changes});
}
const tacticalDefenses = [66, 70].map(ply => {
  const s = replay.states[ply - 1], actual = replay.moves[ply - 1], next = replay.moves[ply];
  const probe = m => {
    const board = s.board.slice(); board[m.from] = -1; board[m.to] = 0;
    const gm = E.pieceMoves(board, next.from, s.rules);
    return {...describe(m), redArrived: E.progress(board, 0), redMatching: A.assignment(board, 0), greenPiece: E.coord(next.from),
      observedNextTarget: E.coord(next.to), observedNextTargetReachable: gm.some(v => v.to === next.to), greenPieceMaxImmediateGain: gain(board, next.from, s.rules)};
  };
  const candidates = E.legalMoves(s.board, 0, s.rules).map(probe).filter(v => !v.observedNextTargetReachable).sort((a, b) => a.greenPieceMaxImmediateGain - b.greenPieceMaxImmediateGain || a.redMatching - b.redMatching);
  return {beforePly: ply, initialRedMatching: A.assignment(s.board, 0), initialGreenMaxImmediateGain: gain(s.board, next.from, s.rules), actualRed: probe(actual), actualNextGreen: describe(next), legalBlockingCandidates: candidates};
});
const masterStyleChains = [67, 69, 71, 73, 77, 81, 83].map(ply => ({ply, ...describe(replay.moves[ply - 1]), bridges: bridges(replay.states[ply - 1].board, replay.moves[ply - 1])}));
const milestones = [30, 42, 43, 47, 52, 56, 66, 67, 70, 71, 74, 83, 94, 95].map(ply => ({ply, greenArrived: E.progress(replay.states[ply].board, 3), redArrived: E.progress(replay.states[ply].board, 0), greenMatching: A.assignment(replay.states[ply].board, 3), redMatching: A.assignment(replay.states[ply].board, 0)}));
const output = {source: path.basename(file), sourceSHA256: crypto.createHash('sha256').update(raw).digest('hex'), plies: record.moves.length,
  method: 'Every stated route and counterfactual first move uses the captured full-star board and production legal move generator. Immediate gain measures distance to the nearest target triangle, not depth-specific goal assignment, turn cost, forced result, or Elo. Counterfactual blocking proves only immediate route denial; the rival may choose another plan. Existing record humanSeat metadata is not used for color interpretation: green=3, red=0 by captured terminal occupancy and actual moves.',
  greenEffects, redSelfEffects, tacticalDefenses, masterStyleChains, milestones,
  unfinishedRedTrajectories: [...redTrack].filter(([cell]) => E.zoneOf[cell] !== 3).map(([cell, t]) => ({final: E.coord(cell), ...t}))};
fs.writeFileSync(path.join(__dirname, 'human-challenge-transport-review.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({plies: output.plies, greenEffects: greenEffects.map(x => ({ply: x.ply, move: x.move, changes: x.changes.map(y => ({piece: y.piece, beforeGain: y.beforeGain, afterGain: y.afterGain}))})), tacticalDefenses, unfinishedRedTrajectories: output.unfinishedRedTrajectories}, null, 2));
