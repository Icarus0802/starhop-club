/* Independent, bounded frozen-opponent completion proof for one captured game.
 * The production rules/search/UI are read only. All ten red pieces may move.
 * A* h = number of red pieces outside their goal: one turn can remove at most
 * one such piece. The geometric rank is a tie breaker, never a pruning bound.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const E = require('../js/engine.js');
const source = path.join(__dirname, 'human-challenge-2026-10-10.json');
const capture = JSON.parse(fs.readFileSync(source, 'utf8'));
const replay = E.replay(capture);
const initial = replay.state;
const player = 0, opponent = 3, goal = E.zones[3];
const deadline = performance.now() + 50000;
const bits = E.cells.map((_, i) => 1n << BigInt(i));
const maskOf = b => b.reduce((m, v, i) => v === player ? m | bits[i] : m, 0n);
const outside = b => 10 - E.progress(b, player);
const rank = b => {
  const holes = goal.filter(i => b[i] !== player);
  let n = 0;
  for (let i = 0; i < 121; i++) if (b[i] === player && E.zoneOf[i] !== 3) {
    const d = Math.min(...holes.map(g => E.distances[i][g])); n += d * d;
  }
  return n;
};
class Heap {
  constructor() { this.a = []; }
  less(x, y) { return x.f < y.f || x.f === y.f && (x.rank < y.rank || x.rank === y.rank && x.g > y.g); }
  push(x) { let i = this.a.length; this.a.push(x); while (i) { const p = (i - 1) >> 1; if (!this.less(x, this.a[p])) break; this.a[i] = this.a[p]; i = p; } this.a[i] = x; }
  pop() { const result = this.a[0], x = this.a.pop(); if (this.a.length) { let i = 0; while (i * 2 + 1 < this.a.length) { let k = i * 2 + 1; if (k + 1 < this.a.length && this.less(this.a[k + 1], this.a[k])) k++; if (!this.less(this.a[k], x)) break; this.a[i] = this.a[k]; i = k; } this.a[i] = x; } return result; }
  get length() { return this.a.length; }
}
if (initial.ply !== 95 || initial.winner !== opponent || E.progress(initial.board, player) !== 8) throw new Error('Captured final state differs');
const start = performance.now(), heap = new Heap(), best = new Map();
const root = {board: initial.board.slice(), mask: maskOf(initial.board), g: 0, f: outside(initial.board), rank: rank(initial.board), parent: null, move: null};
best.set(root.mask, 0); heap.push(root);
let generated = 0, expanded = 0, popped = 0, duplicates = 0, found = null, timedOut = false;
const expandedByF = {};
while (heap.length) {
  if (performance.now() > deadline) { timedOut = true; break; }
  const node = heap.pop(); popped++;
  if (best.get(node.mask) !== node.g) { duplicates++; continue; }
  if (E.isWinner(node.board, player)) { found = node; break; }
  expanded++; expandedByF[node.f] = (expandedByF[node.f] || 0) + 1;
  for (const m of E.legalMoves(node.board, player, initial.rules)) {
    generated++;
    const g = node.g + 1, mask = node.mask ^ bits[m.from] ^ bits[m.to];
    if ((best.get(mask) ?? Infinity) <= g) { duplicates++; continue; }
    const board = node.board.slice(); board[m.from] = -1; board[m.to] = player;
    best.set(mask, g);
    heap.push({board, mask, g, f: g + outside(board), rank: rank(board), parent: node, move: m});
  }
}
const plan = [];
if (found) { for (let n = found; n.parent; n = n.parent) plan.push(n.move); plan.reverse(); }
let board = initial.board.slice();
const verified = plan.map((m, i) => {
  const legal = E.pieceMoves(board, m.from, initial.rules).find(v => v.to === m.to);
  if (!legal) throw new Error('Illegal completion step ' + (i + 1));
  board[m.from] = -1; board[m.to] = player;
  for (let cell = 0; cell < 121; cell++) if ((initial.board[cell] === opponent) !== (board[cell] === opponent)) throw new Error('Frozen opponent changed');
  return {ownTurn: i + 1, from: m.from, to: m.to, fromCoordinate: E.coord(m.from), toCoordinate: E.coord(m.to), path: legal.path.map(E.coord), redArrived: E.progress(board, player)};
});
const result = {
  source: path.basename(source), capturedPlies: initial.ply, capturedWinner: opponent,
  conditions: {player, opponent, frozenOpponent: true, allTenRedPiecesMayMove: true, jump: initial.rules.jump, goalLock: initial.rules.goalLock, alternatingTurns: false, ongoingGameWinClaim: false},
  status: found ? 'found' : timedOut ? 'timeout' : 'exhausted',
  shortestOwnTurns: found ? found.g : null, shortestProven: !!found,
  proof: 'A* exhausts all reachable states with g + h below the winning cost before popping a goal. h = number of outside-goal red pieces is admissible and consistent: a legal own turn changes this count by at most one. Every legal red move is generated; no beam, depth, defense, arrived-piece, or geometric pruning. Position transpositions retain the lowest g. The fixed ten green pieces plus red bitmask uniquely identify occupancy. Hence a popped goal has globally minimum own-turn length under these frozen conditions.',
  expandedByF, generatedLegalEdges: generated, uniqueStates: best.size, expandedStates: expanded, poppedStates: popped, duplicateOrStaleEdges: duplicates,
  timeMs: +(performance.now() - start).toFixed(3), remainingMinimumF: heap.length ? heap.a[0].f : null,
  plan: verified, finalRedArrived: E.progress(board, player), finalGreenArrived: E.progress(board, opponent)
};
if (found && (result.finalRedArrived !== 10 || result.finalGreenArrived !== 10)) throw new Error('Completion verification failed');
fs.writeFileSync(path.join(__dirname, 'human-challenge-frozen-finish.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
