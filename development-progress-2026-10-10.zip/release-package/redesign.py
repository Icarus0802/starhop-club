from pathlib import Path
p=Path('index.html')
old=p.read_text(encoding='utf-8')
rest=old[old.index('      <section id="view-lab"'):]
prefix='''<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#101a1b"><meta name="description" content="星跃棋社：专注中国跳棋的对弈、复盘与 AI 研究。青玉棋室，落子有章。">
  <title>星跃棋社 · 中国跳棋 AI</title>
  <link rel="icon" href="assets/icon.svg" type="image/svg+xml">
  <script>try{const a=JSON.parse(localStorage.getItem('starhop-appearance'));document.documentElement.dataset.theme=a?.theme==='light'?'light':'dark';}catch{document.documentElement.dataset.theme='dark';}</script>
  <link rel="stylesheet" href="style.css">
</head>
<body data-theme="dark">
  <aside class="sidebar">
    <a class="brand" href="#play" aria-label="星跃棋社"><span class="brand-mark">✦</span><span class="brand-name">星跃<small>STARHOP</small></span></a>
    <div class="nav-label">棋社</div>
    <nav aria-label="主导航">
      <button class="nav-item active" data-view="play" aria-label="对弈大厅" title="对弈大厅"><svg class="nav-icon" aria-hidden="true"><use href="assets/ui-icons.svg#board"/></svg><span class="nav-text">对弈</span></button>
      <button class="nav-item" data-view="lab" aria-label="AI 实验室" title="AI 实验室"><svg class="nav-icon" aria-hidden="true"><use href="assets/ui-icons.svg#lab"/></svg><span class="nav-text">研究</span></button>
      <button class="nav-item" data-view="archive" aria-label="我的棋谱" title="我的棋谱"><svg class="nav-icon" aria-hidden="true"><use href="assets/ui-icons.svg#archive"/></svg><span class="nav-text">棋谱</span></button>
      <button class="nav-item" data-view="rules" aria-label="规则与开源" title="规则与开源"><svg class="nav-icon" aria-hidden="true"><use href="assets/ui-icons.svg#info"/></svg><span class="nav-text">关于</span></button>
    </nav>
    <div class="side-note"><span class="note-star">✧</span><b>每一子，都有归途</b><p>看清借力，<br>也看清下一步。</p><button id="quick-lab" title="进入 AI 实验室">研究棋局 <span>↗</span></button></div>
    <div class="local-status"><span></span><small>v1.3</small></div>
  </aside>
  <div class="workspace">
    <header class="topbar">
      <div class="breadcrumb"><span class="mobile-brand">✦ 星跃</span><span class="desktop-brand">星跃棋社</span><span>/</span><b id="page-name">对弈大厅</b></div>
      <div class="top-actions"><span class="local-pill"><i class="live-dot"></i> 本地练棋</span>
        <button class="icon-btn focus-toggle" id="focus-mode" aria-label="进入专注模式" aria-pressed="false" title="专注棋盘"><svg aria-hidden="true"><use href="assets/ui-icons.svg#focus"/></svg></button>
        <button class="icon-btn theme-toggle" id="theme-toggle" aria-label="切换到浅色棋室" aria-pressed="false" title="切换棋室配色"><svg aria-hidden="true"><use id="theme-icon" href="assets/ui-icons.svg#sun"/></svg></button>
        <button class="icon-btn" id="help" aria-label="查看规则" title="规则"><svg aria-hidden="true"><use href="assets/ui-icons.svg#info"/></svg></button>
      </div>
    </header>
    <main>
      <section id="view-play" class="view active">
        <div class="page-intro"><div><span class="eyebrow">THE JADE ROOM</span><h1>星跃棋室</h1><p>专注每一步，照顾每一颗棋子。</p></div><button class="primary" id="new-game"><svg aria-hidden="true"><use href="assets/ui-icons.svg#plus"/></svg> 创建对局</button></div>
        <div class="game-layout">
          <aside class="opponent-art" aria-label="棋手形象与对手信息">
            <div class="portrait-ornament" aria-hidden="true"><span>✦</span></div>
            <span class="section-kicker">YOUR OPPONENT</span>
            <img class="opponent-art-image" src="assets/starhop-strategist.webp" width="768" height="1152" alt="原创东方棋手立绘：青玉与白色服饰，手持翡翠棋子" decoding="async" fetchpriority="high">
            <div class="opponent-profile">
              <span class="profile-tag" id="profile-level">挑战 · 0.35 秒</span>
              <h2 id="profile-name">星河</h2><p id="profile-summary">整队推进，借力而行。</p>
              <div class="profile-status"><i class="live-dot"></i><span id="profile-status">等待落子</span></div>
            </div>
          </aside>
          <div class="board-card board-stage">
            <div class="board-top"><div><span class="live-dot"></span><b id="match-title">人机练习</b><span class="tag" id="rules-tag">相邻跳</span></div><div class="board-tools">
              <button id="coordinates" class="icon-btn" aria-label="显示坐标" aria-pressed="false" title="坐标"><svg aria-hidden="true"><use href="assets/ui-icons.svg#grid"/></svg></button>
              <button id="flip" class="icon-btn" aria-label="翻转棋盘" aria-pressed="false" title="翻转棋盘"><svg aria-hidden="true"><use href="assets/ui-icons.svg#flip"/></svg></button>
              <button id="sound" class="icon-btn" aria-label="开启音效" aria-pressed="false" title="音效"><svg aria-hidden="true"><use href="assets/ui-icons.svg#sound"/></svg></button>
            </div></div>
            <div class="player-strip" id="opponent-strip"></div>
            <p id="record-source" class="record-source" hidden></p>
            <div class="board-wrap board-surface"><svg id="board" viewBox="80 0 560 610" role="group" aria-label="121 孔中国跳棋棋盘"></svg></div>
            <div class="last-action" id="last-action" hidden><div><b id="last-action-title"></b><small id="last-action-path"></small></div><button id="replay-last" title="动画重播上一手">↻ 重播</button></div>
            <div class="player-strip bottom" id="human-strip"></div>
            <div class="turn-message" id="turn-message" role="status" aria-live="polite"></div>
            <div class="board-bottom"><div class="main-controls"><button id="undo" title="撤回到上一次人类行棋前">↶ 悔棋</button><button id="hint">✧ 提示</button><button id="pause" hidden>Ⅱ 暂停</button><button id="resign">⚑ 结束</button></div><button class="quiet" id="save-game">▤ 保存</button></div>
          </div>
          <aside class="match-panel" aria-label="对局分析">
            <section class="panel opponent-panel"><div class="panel-heading"><h2>对局</h2><span id="mode-badge" class="mini-label">人机</span></div><div id="seats"></div><div class="match-meta"><span>规则 <b id="rule-info"></b></span><span>手数 <b id="ply-info">0</b></span></div></section>
            <details class="panel analysis-panel panel-disclosure" id="analysis-disclosure" open>
              <summary class="panel-heading disclosure-heading"><h2>局势</h2><span id="analysis-perspective" class="mini-label"></span></summary>
              <div class="panel-body"><div class="position-head"><b id="position-score">0</b><span id="position-verdict">双方接近</span></div>
              <svg id="trend-chart" viewBox="0 0 520 156" aria-label="整盘局势评分走势"></svg>
              <details class="analysis-detail-disclosure"><summary>后子、堵塞与借力</summary><div id="analysis-details"></div><p id="risk-pieces" class="risk-pieces"></p></details>
              <button id="compare-levels" class="secondary full">对比不同级别 AI 的建议</button><div id="level-comparison" aria-live="polite"></div>
              <details class="fine-print"><summary>评分说明 · 非胜率</summary><p id="analysis-formula"></p><p>点击走势可复盘。风险依据当前借力条件；后续搭桥和阻挡仍需搜索判断。</p></details></div>
            </details>
            <details class="panel search-panel panel-disclosure" id="search-disclosure">
              <summary class="panel-heading disclosure-heading"><h2>AI 思考</h2><span class="engine-pill" id="engine-status">待命</span></summary>
              <div class="panel-body"><div class="search-metrics"><div><b id="search-depth">—</b><span>层数 / 回合</span></div><div><b id="search-nodes">—</b><span>搜索节点</span></div><div><b id="search-time">—</b><span>响应 / 秒</span></div></div><div class="search-summary" id="search-summary"></div><div id="candidates" class="candidates"></div><details id="search-plan" class="search-plan" hidden></details><p class="fine-print">实际搜索数据，评分不是胜率。</p></div>
            </details>
            <details class="panel history-panel panel-disclosure" id="history-disclosure">
              <summary class="panel-heading disclosure-heading"><h2>棋谱</h2><span class="mini-label">逐手复盘</span></summary>
              <div class="panel-body"><div class="history-controls"><button id="first-move" aria-label="回到开局">|‹</button><button id="prev-move" aria-label="上一步">‹</button><span id="history-index">0 / 0</span><button id="next-move" aria-label="下一步">›</button><button id="last-move" aria-label="回到最新">›|</button></div><div class="move-list" id="move-list"><div class="empty">落下第一子，记录就从这里开始。</div></div><button class="return-live" id="return-live" hidden>返回当前对局 →</button><button class="text-btn" id="export-game">导出棋谱 ↗</button></div>
            </details>
          </aside>
        </div>
        <div class="bottom-note"><span>✦</span> 看清上一手，走好下一手。<small>121 孔 · 十子入营 · 本地保存</small></div>
      </section>
'''
rest=rest.replace('正式版 1.2','正式版 1.3')
rest=rest.replace('<dialog id="match-dialog">','<dialog id="match-dialog" aria-labelledby="match-dialog-title">')
rest=rest.replace('<h2>开启一场好棋</h2>','<h2 id="match-dialog-title">开启一场好棋</h2>')
rest=rest.replace('<script src="js/app.js"></script>','<script src="js/presentation.js"></script><script src="js/app.js"></script>')
p.write_text(prefix+rest,encoding='utf-8')
