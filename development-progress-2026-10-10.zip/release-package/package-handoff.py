"""Archive original project progress without republishing external model binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent.parent
out = root / 'release-package'
allowed = {'.json', '.cjs', '.md', '.cpuprofile', '.jpg', '.png', '.py', '.log'}
selected = []
excluded = []
for p in sorted((root / 'arena-results').rglob('*')):
    if not p.is_file():
        continue
    rel = p.relative_to(root).as_posix()
    parts = p.relative_to(root / 'arena-results').parts
    if parts[0] == 'research-package-check':
        reason = 'Duplicate extracted historical source validation checkout; source is preserved in Git versions.'
    elif parts[0] == 'engine-research' and not (len(parts) == 2 and p.suffix == '.json'):
        reason = 'External download or original media; provenance, URLs and hashes retained in project research docs.'
    elif p.suffix.lower() not in allowed or p.is_symlink():
        reason = 'Not an original project research artifact.'
    else:
        selected.append(p)
        continue
    excluded.append({'path': rel, 'bytes': p.stat().st_size, 'reason': reason})

for p in sorted(out.rglob('*')):
    if not p.is_file() or p.is_symlink():
        continue
    parts = p.relative_to(out).parts
    if len(parts) == 1 and (p.suffix.lower() in {'.jpg', '.log'} or p.name in {'redesign.py', 'package-handoff.py'}):
        selected.append(p)
    elif len(parts) > 1 and parts[0] in {'verify', 'verify1.2', 'verify-1.3.0'} and p.suffix == '.log':
        selected.append(p)

rows = []
for p in selected:
    data = p.read_bytes()
    rows.append({'path': p.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {
    'format': 'starhop-development-progress-v1',
    'date': '2026-10-10',
    'sourcePackageSha256': '337caaa83cf55083313e81327aefd3f71a90bcf6d35f31a6b5afa271feb23ad3',
    'note': 'Original bytes retained. Archived trials include historical, exploratory and incomplete runs; archive presence is not evidence of engine strength or a completed experiment.',
    'files': rows,
    'excluded': excluded,
}
manifest_path = out / 'development-progress-2026-10-10.manifest.json'
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
archive_path = out / 'development-progress-2026-10-10.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in selected:
        info = zipfile.ZipInfo(p.relative_to(root).as_posix(), (2026, 10, 10, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(info, p.read_bytes())
    info = zipfile.ZipInfo('DEVELOPMENT_PROGRESS_MANIFEST.json', (2026, 10, 10, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    z.writestr(info, manifest_path.read_bytes())
digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
(out / 'development-progress-2026-10-10.sha256').write_text(digest + '  ' + archive_path.name + '\n', encoding='utf-8')
with zipfile.ZipFile(archive_path) as z:
    assert z.testzip() is None
    for row in rows:
        assert hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256']
print(json.dumps({'files': len(rows), 'rawBytes': sum(x['bytes'] for x in rows), 'archiveBytes': archive_path.stat().st_size, 'sha256': digest, 'excludedFiles': len(excluded)}, ensure_ascii=False))
